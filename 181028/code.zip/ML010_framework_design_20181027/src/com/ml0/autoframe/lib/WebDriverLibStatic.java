package com.ml0.autoframe.lib;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;
import com.report.html.HtmlFileGlobal;



public class WebDriverLibStatic {
	public static Logger logger = Logger.getLogger(DataStore.D_DebugLogger);
	//private WebDriver driver=null;
	public static WebDriver driver=null; 
	private FileHandler fileHandler=null;
	private String browser=DataStore.D_Browser;
	private String baseUrl=DataStore.D_URL;	
		
		/**
	     * Constructor that takes in the instrumentation.
	     *
	     * @param instrumentation the {@link Instrumentation} instance
		 * @return 
	     *
	     */
//	 public WebDriver getDriver(){
//		 if (driver==null)
//		 {
//			 logger.info("driver 启动失败，程序退出！");
//			 System.exit(0);
//		 }
//			 
//		 return driver;
//		 
//	 }
	  
	 public void newSetup(String p_Name)
	   
		
	 	{
		 try {
				fileHandler = new FileHandler(DataStore.D_LogPath+File.separator+"Debug.log",true);
				fileHandler.setFormatter(new SimpleFormatter());
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				logger.severe(e.toString());
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 logger.addHandler(fileHandler);
     	 HtmlFileGlobal.createLog(DataStore.D_LogPath+File.separator+p_Name+CommonLib.getCurrentTime()+".html");

		 if (browser.equalsIgnoreCase("chrome")) {
				// System.setProperty("webdriver.chrome.driver","D:\\MyWorkplace\\webdriverServer\\chromedriver.exe");
				
				 driver = new ChromeDriver();
				 logger.info("启动chrome浏览器。");

		}else if (browser.equalsIgnoreCase("ie")) {

				
					driver = new InternetExplorerDriver();
					logger.info("启动ie浏览器。");
			
		}else if (browser.equalsIgnoreCase("safari")) {
				// System.setProperty("webdriver.safari.noinstall","C:\\Program Files\\Safari\\Safari.exe");
				Platform current = Platform.getCurrent();
				if (Platform.WINDOWS.is(current))
					driver = new SafariDriver();
				logger.info("启动safari浏览器。");

		}else{
				   ProfilesIni pi = new ProfilesIni();
				   FirefoxProfile profile = pi.getProfile("default");
				   driver = new FirefoxDriver(profile);
				   logger.info("启动firefox浏览器。");

			}
		     
//            if (driver!=null)
//            {    
//            	try {
//					fileHandler = new FileHandler(DataStore.D_LogPath+File.separator+"Debug.log",true);
//					fileHandler.setFormatter(new SimpleFormatter());
//				} catch (SecurityException e) {
//					// TODO Auto-generated catch block
//					logger.severe(e.toString());
//					e.printStackTrace();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
            	
            	driver.manage().timeouts().pageLoadTimeout(90, TimeUnit.SECONDS);
    			driver.get(baseUrl);
    			logger.info("获取环境信息："+baseUrl);
    			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    			driver.manage().window().maximize();
    			logger.info("浏览器窗口最大化。");
    			logger.info(TextStore.T_Init + TextStore.T_Pass);
    			//logger.info("初始化成功");
            
			
	 	}
	  
	  public void newTeardown(){
		  
		  logger.info("webdriverLib 销毁");	
		  HtmlFileGlobal.closeLog();
		  driver.quit();
		  fileHandler.close();
		 
			 

	  }
	    
	    public static By parseObject(String p_object) {
			String newObjecyt = null;

			if (p_object.startsWith(".//") || p_object.startsWith("//")) {
				return By.xpath(p_object);
			} else if (p_object.startsWith("link=") || p_object.startsWith("Link=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.linkText(newObjecyt);
			} else if (p_object.startsWith("xpath=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.xpath(newObjecyt);
			} else if (p_object.startsWith("id=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.id(newObjecyt);
			} else if (p_object.startsWith("css=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.cssSelector(newObjecyt);
			} else if (p_object.startsWith("class=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.className(newObjecyt);
			} else if (p_object.startsWith("tagName=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.tagName(newObjecyt);
			} else if (p_object.startsWith("name=")) {
				newObjecyt = p_object.substring(p_object.indexOf("=") + 1);
				return By.name(newObjecyt);
			} else
				return null;

		}
		
		
		public void newClick(String p_id){
			
			CommonLib.sleep(DataStore.D_Wait_ShortTime);
			
			try {
				driver.findElement(parseObject(p_id)).click();
				logger.info(TextStore.T_ClickObject + p_id + TextStore.T_Pass);
				//logger.info("点击对象" + p_id + "成功!");  //这样写也是OK的

			}

			catch (Exception e) {
				logger.severe(TextStore.T_Exception + "newClick(String p_id)"
						+ TextStore.T_DetailInfo + e.toString());

			}
			
			    
		}
	    
		public void newType(String p_id,String p_text){
			CommonLib.sleep(DataStore.D_Wait_ShortTime);
			
			try {
				driver.findElement(parseObject(p_id)).clear(); // 输入文字前，清除文本框中的文字
				driver.findElement(parseObject(p_id)).sendKeys(p_text);
				logger.info(TextStore.T_Input + p_text + TextStore.T_To + p_id
						+ TextStore.T_Pass);

			} catch (Exception e) {
				logger.severe(TextStore.T_Exception + "newType"
						+ TextStore.T_DetailInfo + e.toString());
			}
		}
		
		public void newSelect(String p_id,String p_text){
			CommonLib.sleep(DataStore.D_Wait_ShortTime);
			
			try {
				Select select = new Select(driver.findElement(parseObject(p_id)));
				select.selectByVisibleText(p_text);
				
				logger.info(TextStore.T_SelectListValue + p_id+"内容是"+p_id
						+ TextStore.T_Pass);

			} catch (Exception e) {
				logger.severe(TextStore.T_Exception + "newSelect"
						+ TextStore.T_DetailInfo + e.toString());
			}
		}
			
		
	
	   
	   
	   public void newVerifyEquals(String p_message, Object p_expected,
				Object p_actual) throws Exception {

			if (p_expected.equals(p_actual)) {
				HtmlFileGlobal.write(p_message, p_expected.toString(), p_actual.toString());//写入html report or debug report
				logger.info("");
			
			} else {
				screenshot();
				HtmlFileGlobal.write(p_message, p_expected.toString(), p_actual.toString());//写入html report or debug report
				logger.severe("");
	

				
			}
		}
	   
	   public void newAssertEquals(String p_message, Object p_expected,
				Object p_actual) throws Exception {
	      
			if (p_expected.equals(p_actual)) {
				HtmlFileGlobal.write(p_message, p_expected.toString(), p_actual.toString());//写入html report or debug report
				logger.info("写入html 日志成功！"+"message: "+p_message+";expected: "+p_expected+ ";actual: "+p_actual);
			
			} else {
				screenshot();
				HtmlFileGlobal.write(p_message, p_expected.toString(), p_actual.toString());//写入html report or debug report
				HtmlFileGlobal.closeLog();
			    driver.quit();
				logger.severe("");
	

				
			}
		}
	   
	   
	   public void swithchToWindow(String p_windowName){
		   CommonLib.sleep(DataStore.D_Wait_ShortTime);
		   for (String s : driver.getWindowHandles()) {
				driver.switchTo().window(s);
				if (driver.getTitle().equals(p_windowName)) {
					{
						logger.info("切换到窗口：" + p_windowName + TextStore.T_Pass);
						break;
					}
					
				}
		    }
	   }
	   
	   
	   public void newRunScript(String p_script) {
		   
		   CommonLib.sleep(DataStore.D_Wait_ShortTime);

			try {
				((JavascriptExecutor) driver).executeScript(p_script);
				logger.info("执行jS代码：" + p_script + TextStore.T_Pass);

			} catch (Exception e) {
				logger.severe(TextStore.T_Exception
						+ "newRunScript(String p_script)" + TextStore.T_DetailInfo
						+ e.toString());

			}
	   }
			
			public boolean newIsElementPresent(String p_id) {
			    try {
			      driver.findElement(parseObject(p_id));
			      return true;
			    } catch (NoSuchElementException e) {
			      return false;
			    }
			  }
			
			public void screenshot()
			  
			{

			       File scrFile = ((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);   
			       String screenshot=DataStore.D_ScreenShotPath+File.separator+"screenshot_"+CommonLib.getCurrentTime()+".png";
			       
			       System.out.println(screenshot);
			    		      
			        try {	
	
			            FileUtils.copyFile(scrFile, new File(screenshot));
			            HtmlFileGlobal.setScreenshot(screenshot); //日志接口
			            
			        } catch (IOException e) {
			            // TODO Auto-generated catch block
			       
			            e.printStackTrace();
			        } 
			      
			  }
			
			
	   

	   
}
