package com.ml0.autoframe.lib;

public class AppiumLibAndroid {

}
