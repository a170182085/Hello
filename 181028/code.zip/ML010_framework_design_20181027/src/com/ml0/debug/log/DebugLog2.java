package com.ml0.debug.log;

public class DebugLog2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DebugLogFile.type("case12");
		DebugLogFile.type("case22");

	}

}
