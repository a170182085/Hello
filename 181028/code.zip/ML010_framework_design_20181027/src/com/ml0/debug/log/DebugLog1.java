package com.ml0.debug.log;

public class DebugLog1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DebugLogFile.type("case1");
		DebugLogFile.type("case2");

	}

}
