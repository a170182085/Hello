package com.ml0.debug.log;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import com.ml0.autoframe.lib.DataStore;

public class LoggerDemo2 {
	public static void main(String[] args) throws SecurityException, IOException {
		Logger logger = Logger.getLogger("ttttt");
		FileHandler fileHandler;
		fileHandler = new FileHandler("d:\\ml01027.log",true);
		fileHandler.setFormatter(new SimpleFormatter());
		logger.addHandler(fileHandler);
    	logger.info("info1");
    	logger.info("info2");
    	fileHandler.close();
	
		
	}

}
