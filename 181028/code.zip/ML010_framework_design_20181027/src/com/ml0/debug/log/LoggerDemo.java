package com.ml0.debug.log;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import com.ml0.autoframe.lib.DataStore;

public class LoggerDemo {
	public static void main(String[] args) {
		Logger logger1 = Logger.getLogger(DataStore.D_DebugLogger);
		Logger logger2 = Logger.getLogger(DataStore.D_DebugLogger);
		System.out.println(logger1==logger2);
	
		
	}

}
