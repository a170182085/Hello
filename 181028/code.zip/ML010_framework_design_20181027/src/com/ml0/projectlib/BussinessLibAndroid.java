package com.ml0.projectlib;

public class BussinessLibAndroid extends AndroidDriverLibExtension {

}
