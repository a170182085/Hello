package com.ml0.projectlib;

import com.ml0.autoframe.lib.AppiumLibAndroid;

public class AndroidDriverLibExtension extends AppiumLibAndroid {

}
