package com.ml0.projectlib;


import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.ml0.autoframe.lib.CommonLib;
import com.ml0.autoframe.lib.DataStore;
import com.ml0.autoframe.lib.TextStore;
import com.ml0.autoframe.lib.WebDriverLibStatic;


public class WebdriverLibExtension extends WebDriverLibStatic {
    
	

	public void newClick(String p_id){
		
	    logger.info("********* start newMyClick ******");
		CommonLib.sleep(DataStore.D_Wait_ShortTime);
		
		
		
		try {
			driver.findElement(parseObject(p_id)).click();
			logger.info(TextStore.T_ClickObject + p_id + TextStore.T_Pass);
			//logger.info("点击对象" + p_id + "成功!");  //这样写也是OK的

		}

		catch (Exception e) {
			logger.severe(TextStore.T_Exception + "newClick(String p_id)"
					+ TextStore.T_DetailInfo + e.toString());

		}
		logger.info("********* end newMyClick ******");
	}
	

}
