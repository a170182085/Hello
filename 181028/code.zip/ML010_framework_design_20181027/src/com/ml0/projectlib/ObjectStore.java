package com.ml0.projectlib;


public class ObjectStore {

	public static final  String Login_LoginLink = "css=button.btn.btn-login";
	public static final String Login_LoginFreeLink = "link=登录基础版";
	public static final String Login_LoginEntry ="link=基础版";
	public static final String Login_LoginTab_Username = "name=login_name";
	public static final String Login_LoginTab_Windowname ="登录 - Worktile";
	public static final String Login_LoginTab_Password = "name=login_password";
	public static final String Login_LoginTab_LoginButton = "xpath=//button[@type='button']";
	public static final String Home_ProductLink = "link=产品";
	public static final String Login_LoginTab_AD = "xpath=//*[@id='ng-app']/body/div[1]/div/div/div/div[1]/span/i";
	public static final String Menu_CreateTaskButton="xpath=.//*[@id='btn_leftmenu_shortcut_create']/i";
}