package com.ml0.projectlib;

public class VPStore {
	
	public static String VP_Login="css=span.avatar-text";

}
