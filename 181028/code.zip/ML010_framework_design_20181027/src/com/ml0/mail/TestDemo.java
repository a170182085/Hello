package com.ml0.mail;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		MailEntry me=new MailEntry();
        String users[]={"67674297@qq.com"};
        me.sendmail(users, "d:\\ml0.log");
	}

}
