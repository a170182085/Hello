package com.ml0.mail;

import com.ml0.autoframe.lib.CommonLib;

public class MailDataStore {
	
	public static final String mailconfigfilepaht="./src/com/ml0/mail/mailconfig.ini";
	public static final String host=CommonLib.readINIFile(mailconfigfilepaht, "server", "host");
	public static final String port=CommonLib.readINIFile(mailconfigfilepaht, "server", "port");
	public static final String user=CommonLib.readINIFile(mailconfigfilepaht, "Authenticator", "user");
	public static final String pwd=CommonLib.readINIFile(mailconfigfilepaht, "Authenticator", "pwd");
	public static final String from=CommonLib.readINIFile(mailconfigfilepaht, "MailContent", "from");
	public static final String fromname=CommonLib.readINIFile(mailconfigfilepaht, "MailContent", "fromname");
	public static final String subject="附件测试";
	public static final String message="自动化测试已经结束请查看测试邮件";
	public static final String attachmentpath="";
	public static final String attachmentname="";



}
