package com.ml0.mail;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;

public class TestAttachment {
	
public static void main(String[] args) throws EmailException {
	
	  
	  EmailAttachment attachment = new EmailAttachment();
	  attachment.setPath("d:\\ml0.log");
	  attachment.setDisposition(EmailAttachment.ATTACHMENT);
	  attachment.setName("user.txt");

	  // Create the email message
	  MultiPartEmail email = new MultiPartEmail();
	  email.setHostName("smtp.qq.com");
	  email.setSmtpPort(465);
      email.setAuthenticator(new DefaultAuthenticator("67674297@qq.com", ""));
      email.setSSLOnConnect(true);
      String userlist[]={"67674297@qq.com"};
	  email.addTo(userlist);
	  email.setFrom("67674297@qq.com", "Kevin");
	  email.setSubject("附件测试");
	  email.setMsg("带附件的邮件");

	  // add the attachment
	  email.attach(attachment);

	  // send the email
	  email.send();

	
}

}
