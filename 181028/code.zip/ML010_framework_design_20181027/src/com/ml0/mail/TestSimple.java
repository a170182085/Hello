package com.ml0.mail;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

public class TestSimple {

	public static void main(String[] args) throws EmailException {
		// TODO Auto-generated method stub
		
		Email email = new SimpleEmail();
		email.setHostName("smtp.qq.com");
		email.setSmtpPort(587);
	    email.setAuthenticator(new DefaultAuthenticator("67674297@qq.com", ""));
		email.setSSLOnConnect(true);
		email.setFrom("67674297@qq.com");
		email.setSubject("TestMail");
		email.setMsg("This is a test mail ... :-)");
		email.addTo("67674297@qq.com");
		email.send();


	}

}
