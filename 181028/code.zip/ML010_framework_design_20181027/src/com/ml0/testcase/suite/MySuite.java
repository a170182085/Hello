package com.ml0.testcase.suite;



import com.ml0.autoframe.lib.CommonLib;
import com.ml0.testcase.websetting.Case1;
import com.report.html.HtmlFileGlobal;
import junit.framework.JUnit4TestAdapter;
import junit.framework.Test;
import junit.framework.TestSuite;

public class MySuite {
	
	public static class TestSuite1 {  
		public static Test suite() {  
		TestSuite suite = new TestSuite("Test for package1");  
		  
		suite.addTest(new JUnit4TestAdapter(Case1.class)); //可以根据你的需求加多个case
		//add other
		return suite;  
		}  
		}  
	
	 public static void main(String[] args) throws Exception{
		
		 //HtmlFileGlobal.createLog("d:\\myReport4.html");
         junit.textui.TestRunner.run(TestSuite1.suite());
        // HtmlFileGlobal.closeLog();
         String users[]={"67674297@qq.com"};
		 CommonLib.sendMail(users, "report.html");
         

}
	 
	
	 
}
