package com.ml0.testcase.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import com.ml0.testcase.websetting.Case1;

@RunWith(Suite.class)
@SuiteClasses(Case1.class)
public class AllTests {

}
