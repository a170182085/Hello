package com.ml0.testcase.websetting;

import com.ml0.projectlib.ObjectStore;

public class ObjectStoreMoudule1 extends ObjectStore{

}
