package com.ml0.testcase.websetting;

import com.ml0.projectlib.BussinessLibWeb;

public class M1BussinessLib extends BussinessLibWeb {

	
}
