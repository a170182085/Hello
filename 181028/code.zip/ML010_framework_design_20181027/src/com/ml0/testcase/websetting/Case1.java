package com.ml0.testcase.websetting;



import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ml0.autoframe.lib.CommonLib;
import com.ml0.autoframe.lib.DataStore;
import com.ml0.mail.MailEntry;
import com.ml0.projectlib.BussinessLibWeb;
import com.ml0.projectlib.ObjectStore;

import junit.framework.TestCase;




public class Case1 {

	M1BussinessLib bl = new M1BussinessLib();

	@Before
	public void setUp() throws Exception {

		bl.newSetup("web测试登陆");

	}
   @Test
	public void test() throws Exception {
        
		    //登陆
		    String myCase1="web验证登录";
			bl.login("ml0tester","123456");
			CommonLib.sleep(5);
			bl.newAssertEquals(myCase1,true,false);
			//bl.newAssertEquals(myCase1,true,bl.newIsElementPresent(ObjectStore.Menu_CreateTaskButton));
	        //bl.snapshot();
			//String users[]={"67674297@qq.com"};
			//CommonLib.sendMail(users, "report.html");
			// MailEntry me=new MailEntry();
	        //String users[]={"67674297@qq.com"};
	        //me.sendmail(users, "d:\\myReport3.html");
			
		
	};
	
	@After
	public void tearDown() throws Exception {
		
		bl.newTeardown();
	}

}
