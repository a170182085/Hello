package com.ml0.testcase.websetting;



import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ml0.autoframe.lib.CommonLib;
import com.ml0.autoframe.lib.DataStore;
import com.ml0.mail.MailEntry;
import com.ml0.projectlib.BussinessLibWeb;
import com.ml0.projectlib.ObjectStore;

import junit.framework.TestCase;




public class Case2 {

	M1BussinessLib bl = new M1BussinessLib();

	@Before
	public void setUp() throws Exception {

		bl.newSetup("验证点击产品连接");

	}
   @Test
	public void test() throws Exception {
        
		    //登陆
		    String myCase1="web验证登录";
			//bl.newClick(ObjectStore.Home_ProductLink);
			bl.newVerifyEquals(myCase1, true, true);
			
			String myCase2="web验证登录2";
			//bl.newClick(ObjectStore.Home_ProductLink);
			bl.newVerifyEquals(myCase2, true, false);
			
			String myCase3="web验证登录2";
			//bl.newClick(ObjectStore.Home_ProductLink);
			bl.newVerifyEquals(myCase3, true, true);
			
		
	};
	
	@After
	public void tearDown() throws Exception {
		
		bl.newTeardown();
	}

}
