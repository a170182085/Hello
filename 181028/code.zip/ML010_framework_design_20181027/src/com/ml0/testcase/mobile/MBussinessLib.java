package com.ml0.testcase.mobile;

import com.ml0.autoframe.lib.AppiumLibAndroid;

public class MBussinessLib extends AppiumLibAndroid {

}
