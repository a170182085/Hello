package com.homework;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;

@FixMethodOrder(MethodSorters.NAME_ASCENDING) //不需要加该语句
public class WebTestCase3 {
	String testcase;	
	static BussinessLib bl=new BussinessLib();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		System.out.println("tttttttt");
		bl.newSetup("修改用户信息");		
		//bl.newSetup(DataStore.D_WebSettingDriverType);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		bl.newTeardown();		
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Exception {
		
		testcase="case01-WEB端WorkTile登录";
		//bl.signIn();
		bl.newAssertEquals(testcase, true,true);
		
		testcase="case02-修改个人信息 -个性签名";
		
		bl.newAssertEquals(testcase, true, false);
		
        testcase="case03-修改个人信息 -个性签名";
		
		bl.newAssertEquals(testcase, true, false);
		
		
	}

}
