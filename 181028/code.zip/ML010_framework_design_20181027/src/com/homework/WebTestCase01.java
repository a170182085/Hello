package com.homework;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;

@FixMethodOrder(MethodSorters.NAME_ASCENDING) //不需要加该语句
public class WebTestCase01 {
	String testcase;	
	static BussinessLib bl=new BussinessLib();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		bl.newSetup(null);		
		//bl.newSetup(DataStore.D_WebSettingDriverType);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		bl.newTeardown();		
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Exception {
		
		testcase="WEB端WorkTile登录";
		//bl.newAssertEquals(testcase, true, bl.signIn());	
		
		bl.signIn("ml0tester", "123456");
		//bl.signIn();
		bl.newAssertEquals(testcase, true,bl.newIsElementPresent(VPStore.VP_LOGIN));
		
		testcase="WEB端快速创建日程";
		String[] participantList= {"ml0tester"};		
		bl.newVerifyEquals(testcase, true, bl.createNewCalendar("ML0十期架构练习_Kevin", 
				"ML0十期", 10, 10, 30, 17, 12, 30, "深圳", "不重复", participantList));
		//时间参数稍显复杂
		
		testcase="我的工作台日程中检查新建的日程";
		bl.newVerifyEquals(testcase, true, bl.workBench_Calendar_Search("ML0十期架构练习_Kevin"));
		
		testcase="WEB端WorkTile登出";
		bl.newVerifyEquals(testcase, true, bl.signOut());	
		
	}

}
