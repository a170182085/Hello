package com.homework;

public class VPStore {
	
	public static final String VP_LOGIN="css=span.avatar-text";

}
