package com.homework;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;

@FixMethodOrder(MethodSorters.NAME_ASCENDING) //不需要加该语句
public class WebTestCase2 {
	String testcase;	
	static BussinessLib bl=new BussinessLib();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		bl.newSetup("修改用户信息");		
		//bl.newSetup(DataStore.D_WebSettingDriverType);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		bl.newTeardown();		
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Exception {
		
		testcase="WEB端WorkTile登录";
		//bl.newAssertEquals(testcase, true, bl.signIn());	
		
		bl.signIn("ml0tester", "123456");
		//bl.signIn();
		bl.newAssertEquals(testcase, true,bl.newIsElementPresent(VPStore.VP_LOGIN));
		
		testcase="修改个人信息 -个性签名";
		bl.newClick(ObjectStore.Main_LeftMenu);
		bl.newClick(ObjectStore.Setting_info);
		bl.newClick(ObjectStore.Setting_info_editPerson_INfo);
		bl.newType(ObjectStore.Setting_info_editPerson_INfo_Sigin, "Kevin老师");
		bl.newClick(ObjectStore.Setting_info_editPerson_INfo);
		bl.newClick(ObjectStore.Setting_info_editPerson_SaveButton);
		
		bl.newAssertEquals(testcase, true, bl.newIsTextPresent("Kevin老师"));
		
		
	}

}
