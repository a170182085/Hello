package com.homework;



public class ObjectStore {

	public static final String SignIn_Link = "css=button.btn.btn-login";
	public static final String SignIn_Name = "name=login_name";
	public static final String SignIn_Pass = "name=login_password";
	public static final String SignIn_Submit = ".//button[@type='button']";
	public static final String Worktile_ProductLink="link=产品";
	public static final String Worktile_PriceLink="link=价格";
	public static final String Main_Advertising = "css=i.wtfont.wtf-close";
	public static final String Main_LeftMenu = "css=span.avatar-text";
	
	public static final String Leftmenu_WorkBench ="link=我的";
	public static final String WorkBench_Calendar ="link=日程";
	
	
	public static final String Leftmenu_ShortcutCreate ="css=i.wtfont.wtf-create";	
	public static final String Setting_info="link=账号资料设置";
	public static final String Setting_info_editPerson_INfo="xpath=//div[@id='main']/div/div[2]/data-ui-view/ui-view/div/div/div[2]/dl/ui-view/dd/div[2]/dl[3]/dd/div/button";
	public static final String Setting_info_editPerson_INfo_Sigin="xpath=//div[@id='main']/div/div[2]/data-ui-view/ui-view/div/div/div[2]/dl/ui-view/dd/div[2]/dl[3]/dd/div/form/div[4]/div/textarea";
	public static final String Setting_info_editPerson_SaveButton="xpath=//div[@id='main']/div/div[2]/data-ui-view/ui-view/div/div/div[2]/dl/ui-view/dd/div[2]/dl[3]/dd/div/form/div[5]/div/button";
	public static final String ShortcutCreate_NewCalendar="xpath=.//*[@id='ng-app']/body/div/div/ul/li/a[contains(text(),'日程')]";
	
	

	public static final String CreateNewCalendar_Content="name=event_name";	
	
	public static final String CreateNewCalendar_InProject=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[2]/div/a/span[2]";
	public static final String CreateNewCalendar_InProjectSearch=".//input[@type='search']";
	public static final String CreateNewCalendar_InProjectSearchSelect="css=span.ui-match";	
	
	public static final String CreateNewCalendar_StartDate=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[3]/div/div[1]/span[2]/input";
	public static final String CreateNewCalendar_StartHours=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[3]/div/div[1]/span[2]/select[1]";
	public static final String CreateNewCalendar_StartMinutes=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[3]/div/div[1]/span[2]/select[2]";
	public static final String CreateNewCalendar_EndDate=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[3]/div/div[2]/span[2]/input";
	public static final String CreateNewCalendar_EndHours=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[3]/div/div[2]/span[2]/select[1]";
	public static final String CreateNewCalendar_EndMinutes=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[3]/div/div[2]/span[2]/select[2]";
	public static final String CreateNewCalendar_Location=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[4]/input";
	public static final String CreateNewCalendar_Repetition=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[5]/select";
	
	public static final String CreateNewCalendar_Participant=".//*[@id='ng-app']/body/div[1]/div/div/div/div[2]/form/div[6]/ul/li[2]/a/span";
	public static final String CreateNewCalendar_ParticipantAdd="css=span.o";
	public static final String CreateNewCalendar_ParticipantSearch="name=search_user_input";
	public static final String CreateNewCalendar_ParticipantSearchSelect=".//li/a/span[2]";
	
	public static final String CreateNewCalendar_Save=".//*[@id='ng-app']//button[@wt-loading-status='vm.saving']";
	public static final String CreateNewCalendar_Cancel=".//*[@id='ng-app']//button[@ng-click='vm.close()']";
	
	
	
	
	
	
	
	public static final String SignOut_Link = "link=退出登录";
	
}