package com.homework;

public class BussinessLib extends WebDriverLib {

	/**
	 * signIn 登录 用户读取配置文件
	 * 
	 * @return Boolean
	 */
	public Boolean signIn() {

		if (!newIsElementPresent(ObjectStore.Main_LeftMenu)) {
			if (newIsElementPresent(ObjectStore.SignIn_Link)) {
				newClick(ObjectStore.SignIn_Link);
				newType(ObjectStore.SignIn_Name, DataStore.D_UserInforName);
				newType(ObjectStore.SignIn_Pass, DataStore.D_UserInforPass);
				newClick(ObjectStore.SignIn_Submit);
				CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
				// 检查首次广告提示页
				if (newIsElementPresent(ObjectStore.Main_Advertising))
					newClick(ObjectStore.Main_Advertising);
			}
		}
		return newIsElementPresent(ObjectStore.Main_LeftMenu);
	}
	
	public  void signIn(String p_user,String p_pwd) {

		if (!newIsElementPresent(ObjectStore.Main_LeftMenu)) {
			if (newIsElementPresent(ObjectStore.SignIn_Link)) {
				newClick(ObjectStore.SignIn_Link);
				newType(ObjectStore.SignIn_Name, p_user);
				newType(ObjectStore.SignIn_Pass,p_pwd);
				newClick(ObjectStore.SignIn_Submit);
				CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
				// 检查首次广告提示页
				if (newIsElementPresent(ObjectStore.Main_Advertising))
					newClick(ObjectStore.Main_Advertising);
			}
		}
		
	}

	/**
	 * SignOut 登出
	 * 
	 * @param driver
	 * @return
	 */
	public Boolean signOut() {
		newClick(ObjectStore.Main_LeftMenu);
		newClick(ObjectStore.SignOut_Link);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		return newIsElementPresent(ObjectStore.SignIn_Link);
	}

	public Boolean createNewCalendar(String p_Calendar_Content, String p_Calendar_InProject, int p_Calendar_StartDate,
			int p_Calendar_StartHours, int p_Calendar_StartMinutes, int p_Calendar_EndDate, int p_Calendar_EndHours,
			int p_Calendar_EndMinutes, String p_Calendar_Location, String p_Calendar_Repetition,
			String[] p_Calendar_Participant) {

		newClick(ObjectStore.Leftmenu_ShortcutCreate);
		newClick(ObjectStore.ShortcutCreate_NewCalendar);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);//不需要在写了
		newType(ObjectStore.CreateNewCalendar_Content, p_Calendar_Content);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		newClick(ObjectStore.CreateNewCalendar_InProject);
		newType(ObjectStore.CreateNewCalendar_InProjectSearch, p_Calendar_InProject);
		newClick(ObjectStore.CreateNewCalendar_InProjectSearchSelect);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		newClick(ObjectStore.CreateNewCalendar_StartDate);
		newClick("link=" + p_Calendar_StartDate);
		newSelect(ObjectStore.CreateNewCalendar_StartHours, String.valueOf(p_Calendar_StartHours));
		newSelect(ObjectStore.CreateNewCalendar_StartMinutes, String.valueOf(p_Calendar_StartMinutes));
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		newClick(ObjectStore.CreateNewCalendar_EndDate);
		newClick("link=" + p_Calendar_EndDate);
		newSelect(ObjectStore.CreateNewCalendar_EndHours, String.valueOf(p_Calendar_EndHours));
		newSelect(ObjectStore.CreateNewCalendar_EndMinutes, String.valueOf(p_Calendar_EndMinutes));
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		newType(ObjectStore.CreateNewCalendar_Location, p_Calendar_Location);
		newSelect(ObjectStore.CreateNewCalendar_Repetition, p_Calendar_Repetition);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		if (p_Calendar_Participant.length > 0) {
			newClick(ObjectStore.CreateNewCalendar_ParticipantAdd);
			for (int i = 0; i < p_Calendar_Participant.length; i++) {
				newType(ObjectStore.CreateNewCalendar_ParticipantSearch, p_Calendar_Participant[i].toString().trim());
				newClick(ObjectStore.CreateNewCalendar_ParticipantSearchSelect);
			}
		}
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		newClick(ObjectStore.CreateNewCalendar_Save);
		return true;
	}
	
	public Boolean workBench_Calendar_Search(String p_searchCalendarName) {
		
		newClick(ObjectStore.Leftmenu_WorkBench);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		newClick(ObjectStore.WorkBench_Calendar);
		CommonLib.waitTime(DataStore.D_WebSettingWaitTime);
		return newElementGetText(".//*[@id='calendar']//div/div/table/tbody/tr/td/a/div/span[contains(text(),'"+p_searchCalendarName+"')]").equals(p_searchCalendarName.trim());
	}

}
