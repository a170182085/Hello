package com.homework;

import java.util.logging.Level;

//与外部文件的一个接口
public class DataStore {
	public static String D_IniConfig="./config/config.ini";
	
	public static String D_ReportPath=CommonLib.iniFileRead(D_IniConfig, "Report", "Path");
	
	public static String D_LogPath=CommonLib.iniFileRead(D_IniConfig, "Log", "Path");
	public static Level D_LogSetLevel=Level.parse(CommonLib.iniFileRead(D_IniConfig, "Log", "SetLevel"));
	
	public static String D_WebSettingDriverPath=CommonLib.iniFileRead(D_IniConfig, "WebSetting", "DriverPath");
	public static String D_WebSettingDriverType=CommonLib.iniFileRead(D_IniConfig, "WebSetting", "DriverType");
	public static String D_WebSettingWebUrl=CommonLib.iniFileRead(D_IniConfig, "WebSetting", "WebUrl");
	public static int D_WebSettingTimeOut=Integer.parseInt(CommonLib.iniFileRead(D_IniConfig, "WebSetting", "TimeOut"));
	public static int D_WebSettingMethodWaitTime=Integer.parseInt(CommonLib.iniFileRead(D_IniConfig, "WebSetting", "MethodWaitTime"));
	public static int D_WebSettingWaitTime=Integer.parseInt(CommonLib.iniFileRead(D_IniConfig, "WebSetting", "WaitTime"));
	
	public static String D_UserInforName=CommonLib.iniFileRead(D_IniConfig, "UserInfo", "UserName");
	public static String D_UserInforPass=CommonLib.iniFileRead(D_IniConfig, "UserInfo", "UserPass");
	
			
}
